:- initialization(main).
main :- write('fricken_lazer_beams').

first([A|_],A).
first_rest([A|B],A,B).
nums_down(Y,Y,[Y]).
nums_down(X,Y,[X|B]):-A is X-1, nums_down(A,Y,B).
nums_up(Y,Y,[Y]).
nums_up(X,Y,[X|B]):-A is X+1, nums_up(A,Y,B).
xy_point(P,X,Y):-first_rest(P,X,Ry),first_rest(Ry,Y,_).
blocked_x([_,0],[]):-!.
blocked_x([A,B],[C|D]):-C is A+B, E is B-1, blocked_x([A,E],D).
blocked_y([_,0],[]):-!.
blocked_y([_,B],[C|D]):-C is 11-B, E is B-1, blocked_y([_,E],D).
combine_x_vals([],[_|_],[]):-!.
combine_x_vals(A,B,[X|Y]):-segregate(A,C,D), segregate(B,E,_), coordinate(C,E,X), combine_x_vals(D,B,Y).
coordinate(X,Y,[X,Y]).
combine_y_vals([_|_],[],[]):-!.
combine_y_vals(A,B,R):-segregate(B,_,F), combine_x_vals(A,B,X), combine_y_vals(A,F,Y), append(X,Y,R).
segregate([A|B],A,B).
abc_s(Q,A,B,C):-segregate(Q,A,Brest), segregate(Brest,B,Crest), segregate(Crest,C,_).
get_last([First|[]],First):-!.
get_last([_|Rest],X):-get_last(Rest,X).
is_height([_,Y,_],Height):-Y = Height.

%returns the list of points that are illegal to be in
obstacle_spaces([],[]):-!.
obstacle_spaces(Q,Points):-first_rest(Q,O,Or),abc_s(O,Offset,Xval,Yval),
    blocked_x([Offset,Xval],BX1),blocked_y([Offset,Yval],BY1),combine_y_vals(BX1,BY1,Z1),
    obstacle_spaces(Or,Z2),append(Z1,Z2,Points).
    
human(Offset,Res):-Plus is Offset+1,Res =
        [[Offset,1],[Offset,2],[Offset,3],[Offset,4],[Offset,5],[Offset,6]
        ,[Plus,1],[Plus,2],[Plus,3],[Plus,4],[Plus,5],[Plus,6]].

% in moving right, hits /, goes up, recieved by /.
next_mirror_info(right,up,/).
% in moving right, hits \, goes down, recieved by \.
next_mirror_info(right,down,\).
% in moving up, hits /, goes right, recieved by /.
next_mirror_info(up,right,/).
% in moving down, hits \, goes right, recieved by \.
next_mirror_info(down,right,\).
    
% checks to see if the mirror has been placed on either side of an obstacle
% by checking if any of the values between the mirrors is in AllBlocks
does_crosses_spaces(_,AllBlocks,NewX,NewY,NewX,NewY,[Res]):- member([NewX,NewY],AllBlocks),Res is 0,!.
does_crosses_spaces(_,AllBlocks,NewX,NewY,NewX,NewY,[Res]):- \+member([NewX,NewY],AllBlocks),Res is 1,!.

does_crosses_spaces(right,AllBlocks,OldX,OldY,NewX,NewY,[Ent|Res]):- member([OldX,OldY],AllBlocks),Ent is 0,
    Xpl is OldX+1,Ypl is OldY,does_crosses_spaces(right,AllBlocks,Xpl,Ypl,NewX,NewY,Res).
does_crosses_spaces(right,AllBlocks,OldX,OldY,NewX,NewY,[Ent|Res]):- \+member([OldX,OldY],AllBlocks),Ent is 1,
    Xpl is OldX+1,Ypl is OldY,does_crosses_spaces(right,AllBlocks,Xpl,Ypl,NewX,NewY,Res).
   
does_crosses_spaces(down,AllBlocks,OldX,OldY,NewX,NewY,[Ent|Res]):- member([OldX,OldY],AllBlocks),Ent is 0,
    Xpl is OldX,Ypl is OldY-1,does_crosses_spaces(down,AllBlocks,Xpl,Ypl,NewX,NewY,Res).
does_crosses_spaces(down,AllBlocks,OldX,OldY,NewX,NewY,[Ent|Res]):- \+member([OldX,OldY],AllBlocks),Ent is 1,
    Xpl is OldX,Ypl is OldY-1,does_crosses_spaces(down,AllBlocks,Xpl,Ypl,NewX,NewY,Res).
   
does_crosses_spaces(up,AllBlocks,OldX,OldY,NewX,NewY,[Ent|Res]):- member([OldX,OldY],AllBlocks),Ent is 0,
    Xpl is OldX,Ypl is OldY+1,does_crosses_spaces(up,AllBlocks,Xpl,Ypl,NewX,NewY,Res).
does_crosses_spaces(up,AllBlocks,OldX,OldY,NewX,NewY,[Ent|Res]):- \+member([OldX,OldY],AllBlocks),Ent is 1,
    Xpl is OldX,Ypl is OldY+1,does_crosses_spaces(up,AllBlocks,Xpl,Ypl,NewX,NewY,Res).

% generates all the spaces that the mirror could go except in a blocked space
place_mirror(up,LastPosX,LastPosY,Blockeds,LastPosX,Y):-LastYP is LastPosY+1,between(LastYP,10,Ya),\+member([LastPosX,Ya],Blockeds),
    Y is Ya.
place_mirror(right,LastPosX,LastPosY,Blockeds,X,LastPosY):-LastXP is LastPosX+1,between(LastXP,11,Xa),\+member([Xa,LastPosY],Blockeds),
    X is Xa.
place_mirror(down,LastPosX,LastPosY,Blockeds,LastPosX,Y):-LastYM is LastPosY-1,between(1,LastYM,Ya),\+member([LastPosX,Ya],Blockeds),
    Y is Ya.

% this is where the results get added to each other
try(_,_,_,_,_,8,[]):-!.
try(Des,Xdist,Des,AllBlocks,right,_,[Mirror|Rest]):-does_crosses_spaces(right,AllBlocks,Xdist,Des,12,Des,Res),
    \+member(0,Res),Mirror = [], MPlus is 8,try(_,_,_,AllBlocks,_,MPlus,Rest).
try(Des,Xdist,Ydist,AllBlocks,Dir,Moves,[Mirror|Rest]):-place_mirror(Dir,Xdist,Ydist,AllBlocks,X,Y),
    next_mirror_info(Dir,Ndir,Nmir),does_crosses_spaces(Dir,AllBlocks,Xdist,Ydist,X,Y,Res),
    \+member(0,Res),Mirror = [X,Y,Nmir],MPlus is Moves+1,try(Des,X,Y,AllBlocks,Ndir,MPlus,Rest).

place_mirrors(Height,Obstacles,Result):-obstacle_spaces(Obstacles,Blockeds),between(3,8,X),human(X,HSpaces),
    append(Blockeds,HSpaces,AllBlocks),try(Height,1,Height,AllBlocks,right,0,ResultA),get_last(ResultA,L),
    is_height(L,Height),Result = ResultA.
