
object MicroParser {
  def main(args: Array[String]) {
      val scone = new java.util.Scanner(System.in)
      print("Please input string:\n")
      val input = scone.next()
      var list = new java.util.ArrayList()
      
      abstract class Tree
      case class SNode(v: String, c: Tree) extends Tree
      case class ENode(v: String, c: Tree, e2: Tree) extends Tree
      case class CNode(v: String, c: Tree) extends Tree
      case class E2Node(v: String, c: Tree) extends Tree
      case class Const(v: String) extends Tree
      
      def quickMaffs(two: Int): Int ={
        two+two/*is four*/-1/*is three, quick maffs!*/
      }
      
      /*   
       *   	S -> E
  		 *		E -> C E2
 			 *	 	E2 -> E
  		 *		E2 -> NIL
  		 *		C -> 'a' | 'b'
  		 * 
       */
      
      var index : Int = 0
      var valid : Boolean = true
      if(!input.equals("")){
        val output = parseS(input)
        if(valid){
          println(printTree(output))
        }
        else {
          println("Not valid")
        }
      }
      else {
        println("Not a valid input")
      }
      
      def parseS(input: String): Tree = {
        SNode("S", parseE(input))
      }
      
      def parseE(input: String): Tree = {
        ENode("E", parseC(input), parseE2(input))
      }
      
      def parseC(input: String): Tree = {
        CNode("C", parseConst(input))
      }
      
      def parseConst(input: String): Tree = {
        if(!input.equals("") && index < input.length()) {
          val c : String = input.substring(index, index+1)
          if(c.equals("a")){
            index = index+1
            Const("a")
          }
          else if(c.equals("b")){
            index = index+1
            Const("b")
          }
          else {
            valid = false
            index = index+1
            Const("z")
          }
        }
        else {
          Const("_")
        }
      }
      
      def parseE2(input: String): Tree = {
        if(index < input.length()){
          E2Node("E2", parseE(input))
        }
        else {
          E2Node("E2", parseConst(input))
        }
      }
      
      def printTree(t: Tree): String = t match {
        case SNode(v, c) => v + printTree(c)
        case ENode(v, c, e2) => v + printTree(c) + printTree(e2)
        case CNode(v, c) => v + printTree(c)
        case E2Node(v, c) => v + printTree(c)
        case Const(v) => v 
      }
    }
}