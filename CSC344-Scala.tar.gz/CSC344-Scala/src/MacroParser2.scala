

  object MacroParser2 {
    def main(args: Array[String]) {
      val scone = new java.util.Scanner(System.in);
      println("Please input the grammar pattern.")
      val pattern = scone.nextLine();
      val letter = ".".r 
      
      var index = 0
      
      abstract class Tree
      case class Const(v: String) extends Tree
      case class SNode(e: Tree) extends Tree
      case class ENode(t: Tree, E2: Tree) extends Tree
      case class E2Node(Bar: String, E3: Tree) extends Tree
      case class E3Node(t: Tree, E2: Tree) extends Tree
      case class TNode(f: Tree, T2: Tree) extends Tree
      case class FNode(a: Tree, F2: Tree) extends Tree
      case class AANode(c: Tree) extends Tree
      case class ABNode(OpenPar: String, A2: Tree) extends Tree
      case class A2Node(e: Tree, ClosePar: String) extends Tree
      case class F2Node(QMark: String, F2: Tree) extends Tree
      case class T2Node(f: Tree, T2: Tree) extends Tree
      
      
      /*
      -S  -> E
      -E  -> T E2
      -E2 -> '|' E3
      -E2 -> NIL
      -E3 -> T E2
      -T  -> F T2
      -T2 -> F T2
      -T2 -> NIL
      -F  -> A F2
      -F2 -> '?' F2
      -F2 -> NIL
      -A  -> C
      -A  -> '(' A2
      -A2 -> E ')'
       */  
      
      def process(pattern: String): Tree = {
        println("S")
        SNode(parseENode(pattern))
      }
      
      def parseENode(pattern: String): Tree = {
        println("E")
        ENode(parseTNode(pattern), parseE2Node(pattern))
      }
      
      def parseTNode(pattern: String): Tree = {
        println("T")
        TNode(parseFNode(pattern), parseT2Node(pattern))
      }
      
      def parseFNode(pattern: String): Tree = {
        println("F")
        FNode(parseANode(pattern), parseF2Node(pattern))
      }
      
      def parseANode(pattern: String): Tree = {
        println("A")
        if((index+1)<=pattern.length()
            &&pattern.substring(index, index+1).equals("(")){
          index = index+1
          ABNode("(", parseA2Node(pattern))
        }
        else {
          AANode(parseConst(pattern))
        }
      }
      
      def parseConst(pattern: String): Tree = {
        println("C")
        println("Index is now: "+index)
        println("Char at index: "+pattern.substring(index, index+1))
        index = index+1
        if(pattern.substring(index-1, index).equals(")")||
            index>=pattern.length()){
          println("Stupid char found.")
          Const("")
        }
        else {
          println("Const being added: "+pattern.substring(index-1, index))
          if(pattern.substring(index, index+1).equals(")")){
            index = index + 1
            println("Skipped over )")
            println("Index now points to "+pattern.substring(index, index+1))
            Const(pattern.substring(index-2, index-1))
          }
          else Const(pattern.substring(index-1, index))
        }
      }
      
      def parseA2Node(pattern: String): Tree = {
        println("A2")
        A2Node(parseENode(pattern), ")")
      }
      
      def parseE2Node(pattern: String): Tree = {
        println("E2")
        println("Parsing E2Node. ")
        if((index+1)<=pattern.length()
            &&pattern.substring(index, index+1).equals("|")){
          index=index+1
          println("| found")
          E2Node("|", parseE3Node(pattern))
        }
        else {
          println("End of options")
          Const("")
        }
      }
      
      def parseE3Node(pattern: String): Tree = {
        println("E3")
        E3Node(parseTNode(pattern), parseE2Node(pattern))
      }
      
      def parseF2Node(pattern: String): Tree = {
        println("F2")
        if((index+1)<=pattern.length()
            &&pattern.substring(index, index+1).equals("?")){
          index = index + 1
          F2Node("?", parseF2Node(pattern))
        }
        else {
          Const("")
        }
      }
      
      def parseT2Node(pattern: String): Tree = {
        println("T2")
        if(index<pattern.length()&&
            (!pattern.substring(index, index+1).equals("?"))&&
            (!pattern.substring(index, index+1).equals(")"))&&
            (!pattern.substring(index, index+1).equals("|"))){
          T2Node(parseFNode(pattern), parseT2Node(pattern))
        }
        else {
          Const("")
        }
      }
      
      def printTree(t: Tree): String = t match {
        case SNode(e) => printTree(e)
        case ENode(t, e2) => printTree(t) + printTree(e2)
        case E2Node(bar, e3) => "|" + printTree(e3)
        case E3Node(t, e2) => printTree(t) + printTree(e2)
        case TNode(f, t2) => printTree(f) + printTree(t2)
        case FNode(a, f2) => printTree(a) + printTree(f2)
        case AANode(c) => printTree(c)
        case ABNode(openpar, a2) => openpar+printTree(a2)
        case A2Node(e, closepar) => printTree(e)+closepar
        case F2Node(qmark, f2) => "?" + printTree(f2)
        case T2Node(f, t2) => printTree(f) + printTree(t2)
        case Const(v) => v 
      }
      
      var list = new java.util.ArrayList[String]
      val grammar = process(pattern)
      
      def analyse(grammar: Tree): String = grammar match{
        //good
        case SNode(e) => analyse(e)
        //maybe
        case ENode(t, e2) => {
          analyse(t); analyse(e2); "";
        }
        //good
        case E2Node(bar, e3) => analyse(e3)
        //maybe
        case E3Node(t, e2) => {
          analyse(t); analyse(e2); "";
        }
        //maybe
        case TNode(f, t2) => {
          list.add(analyse(f)+analyse(t2));
          list.add(analyse(t2));
          analyse(t2)
        }
        //maybe
        case FNode(a, f2) => analyse(a)+analyse(f2)
        //good
        case AANode(c) => analyse(c)
        case ABNode(openpar, a2) => analyse(a2)
        //good
        case A2Node(e, closepar) => analyse(e)
        //maybe        
        case F2Node(qmark, f2) => analyse(f2)
        //maybe
        case T2Node(f, t2) => analyse(f)+analyse(t2)
        //good
        case Const(v) => {
          v
        }
      }
      
      analyse(grammar)
      println(printTree(grammar))
      println("Enter 'q' at any time to quit.")
      var input = "L";
      while(!input.toUpperCase().equals("Q")){
        println("Please give an input.")
        input = scone.nextLine()
        index = 0
        var matches = false
        println(printTree(grammar))
        for(x <- 0 until list.size()){
          println(x+": "+list.get(x))
          if(input.equals(list.get(x))){
            matches = true
          }
        }
        if(matches){
          println("Matches.")
        }
        else println("Does not match.")
      }
      println("Goodbye.")
    }
  }
