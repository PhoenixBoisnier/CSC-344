import java.util.ArrayList

  object MacroParser3 {
    def main(args: Array[String]) {
      val scone = new java.util.Scanner(System.in);
      println("Please input the grammar pattern.")
      val pattern = scone.nextLine();
      val letter = ".".r 
      
      var index = 0
      
      abstract class Tree
      case class Const1(v: String) extends Tree
      case class ENode1(t: Tree, e2: Tree) extends Tree
      case class ENode2(t: Tree, e2: Tree) extends Tree
      case class TNode1(a: Tree, t2: Tree) extends Tree
      case class ANode1(c: Tree) extends Tree
      case class ANode2(e: Tree) extends Tree
      
      /*
      -S  -> E
      -E  -> T E2
      -E2 -> '|' T E2
      -E2 -> NIL
      -T  -> A T
      -T -> NIL
      -A  -> C
      -A  -> '(' E ')'
       */
      
      def parseHead(input: String): Tree = {
        if(!input.equals("")){
          parseENode1(input)
        }
        else Const1("")
      }
      
      def parseENode1(input: String): Tree = {
        println("E1")
        ENode1(parseTNode1(input),parseENode2(input))
      }
      
      def parseENode2(input: String): Tree = {
        println("E2")
        if(index<input.length()&&input.substring(index-1,index).equals("|")){
          println("Bar found.")
          ENode2(parseTNode1(input),parseENode2(input))
        }
        else {
          Const1("")
        }
      }
      
      def parseTNode1(input: String): Tree = {
        println("T")
        if(index>=input.length()
            ||input.substring(index,index+1).equals("|")
            ||input.substring(index,index+1).equals(")")){
          index = index+1
          Const1("")
        }
        else {
          TNode1(parseANode1(input),parseTNode1(input))
        }
      }
      
      def parseANode1(input: String): Tree = {
        println("A")
        if(index>=input.length()){
          Const1("")
        }
        else if(input.substring(index,index+1).equals("(")){
          index = index+1
          ANode2(parseENode1(input))
        }
        else {
          index = index+1
          println("Adding: "+input.substring(index-1,index))
          ANode1(Const1(input.substring(index-1,index)))
        }
      }
      
      def replaceQMark(input: String): String = {
        var index = input.length() 
        var output = ""
        while(index>0){
          if(!input.substring(index-1, index).equals("?")){
            output = input.substring(index-1, index)+output
          }
          else {
            if(!input.substring(index-2, index-1).equals(")")){
              output = "("+input.substring(index-2, index-1)+"|_)"+output
              index = index-1
            }
            else {
              var subIndex = index-3
              var parCount = 1
              while(parCount>0){
                if(input.substring(subIndex, subIndex+1).equals(")")){
                  parCount = parCount+1
                }
                if(input.substring(subIndex, subIndex+1).equals("(")){
                  parCount = parCount-1
                }
                subIndex = subIndex-1
              }
              index = index-2
              output = input.substring(subIndex+2,index)+"|_)"+output
              index = subIndex+3
            }
          }
          index = index-1
        }
        if(output.contains("?")){
          output = replaceQMark(output)
        }
        output
      }
      
      /*
      -S  -> E
      -E  -> T E2
      -E2 -> '|' T E2
      -E2 -> NIL
      -T  -> A T
      -T -> NIL
      -A  -> C
      -A  -> '(' E ')'
       */
      def printTree(t: Tree): String = t match {
        case Const1(v)=>v
        case ENode1(t,e2)=>printTree(t)+printTree(e2)
        case ENode2(t,e2)=>"|"+printTree(t)+printTree(e2)
        case TNode1(a,t2)=>printTree(a)+printTree(t2)
        case ANode1(c)=>printTree(c)
        case ANode2(e)=>"("+printTree(e)+")"
      }
      
      var list = new ArrayList[String]
      
      /*
       * This checks to see if there is a | outside of parenthesis. If it is
       * then it returns false.
       */
      def andFirst(substring: String): Boolean = {
        
        var result : Boolean = true
        
        var openPar = 0
        var indexxx = 0
        while(indexxx<substring.length()){
          if(openPar==0){
            if(substring.substring(indexxx,indexxx+1).equals("|")){
              result = false
            }
          }
          if(substring.substring(indexxx,indexxx+1).equals("(")){
            openPar = openPar + 1
          }
          if(substring.substring(indexxx,indexxx+1).equals(")")){
            openPar = openPar - 1
          }
          indexxx = indexxx + 1
        }
        result
      }
      
      def indexOfBar(substring: String): Integer = {
        
        var result = 0
        
        var openPar = 0
        var indexxx = 0
        while(indexxx<substring.length()){
          if(openPar==0){
            if(substring.substring(indexxx,indexxx+1).equals("|")){
              result = indexxx
            }
          }
          if(substring.substring(indexxx,indexxx+1).equals("(")){
            openPar = openPar + 1
          }
          if(substring.substring(indexxx,indexxx+1).equals(")")){
            openPar = openPar - 1
          }
          indexxx = indexxx + 1
        }
        result
      }
      
      def makeOptions(substring: String): ArrayList[String] = {
        
        println("Making options for "+substring)
        
        var firstHalf : String = ""
        var secndHalf : String = ""
        var thirdHalf : String = ""
        var resultzzz : ArrayList[String] = new ArrayList[String]
        
        //Base case where the substring is nothing
        if(substring.equals("")){
          println("Useless.")
          var empty : ArrayList[String] = new ArrayList[String]
          empty.add("")
          resultzzz = empty
        }
        
        //base case where the substring has nothing nested
        else if(!(substring.contains("(")||substring.contains("|"))){
          var value : ArrayList[String] = new ArrayList[String]
          value.add(substring)
          println("Value found. It's "+substring)
          resultzzz = value
        }
        
        /*
         * If the string contains a (, then it has a ) and that means there's
         * something that needs further analysis. This breaks it down into 
         * the smaller parts then calls make options on those parts. They are
         * added together.
         */       
        else if(substring.contains("(")&&andFirst(substring)){
          println("More work to do.")
          
          var adderzz : ArrayList[String] = new ArrayList[String]
          var openPar = 1
          var endex = substring.indexOf("(")+1
          
          while((openPar>0)&&(endex<substring.length())){
            if(substring.substring(endex,endex+1).equals("(")){
              openPar = openPar + 1
            }
            if(substring.substring(endex,endex+1).equals(")")){
              openPar = openPar - 1
            }
            if(openPar!=0){
              endex = endex + 1
            }
          }
          
          //firstHalf will be everything before the (
          firstHalf = substring.substring(0,substring.indexOf("("))
          //secndHalf will be everything inbetween the ()
          secndHalf = substring.substring(substring.indexOf("(")+1,endex)
          //thirdHalf will be everything after the )
          if(endex+1>substring.length()){
            thirdHalf = ""
          }
          else thirdHalf = substring.substring(endex+1,substring.length())
          
          println("First half: "+firstHalf)
          println("Secnd half: "+secndHalf)
          println("Third half: "+thirdHalf)
          
          var firstBits = makeOptions(firstHalf)
          var secndBits = makeOptions(secndHalf)
          var thirdBits = makeOptions(thirdHalf)
          
          //this adds all the options from each half together and puts it into
          //the resulting arrayList
          for(x <- 0 until firstBits.size()){
            for(y <- 0 until secndBits.size()){
              for(z <- 0 until thirdBits.size()){
                adderzz.add(""+firstBits.get(x)+secndBits.get(y)+thirdBits.get(z))
              }
            }
          } 
          resultzzz = adderzz
        }
        //therefore, the substring must include a |
        else {
          println("More work to sort through.")
          println("The string is "+substring)
          
          var orzzzzzzzzzzzzzz : ArrayList[String] = new ArrayList[String]
          var forRealFirstHalf : String = ""
          var forRealSecndHalf : String = ""
          var arrrr : ArrayList[String] = new ArrayList[String]
          
          forRealFirstHalf = substring.substring(0,indexOfBar(substring))
          forRealSecndHalf = substring.substring(indexOfBar(substring)+1,substring.length())
          arrrr = makeOptions(forRealFirstHalf)
          for(x <- 0 until arrrr.size()){
            orzzzzzzzzzzzzzz.add(arrrr.get(x))
          }
          
          println("First half of or "+forRealFirstHalf)
          println("Secnd half of or "+forRealSecndHalf)
          
          while(forRealSecndHalf.contains("|")){
            forRealFirstHalf = substring.substring(0,indexOfBar(substring))
            forRealSecndHalf = substring.substring(indexOfBar(substring)+1,substring.length())
            arrrr = makeOptions(forRealFirstHalf)
            for(x <- 0 until arrrr.size()){
              orzzzzzzzzzzzzzz.add(arrrr.get(x))
            }
          }
          if(forRealSecndHalf.equals("_")){
            arrrr = makeOptions("")
            for(x <- 0 until arrrr.size()){
              orzzzzzzzzzzzzzz.add(arrrr.get(x))
            }
          }
          else {
            arrrr = makeOptions(forRealSecndHalf)
            for(x <- 0 until arrrr.size()){
              orzzzzzzzzzzzzzz.add(arrrr.get(x))
            }
          }
          resultzzz = orzzzzzzzzzzzzzz
        }
        resultzzz
      }
      
      def analyseDisBitch(input: String, allWordsMF: ArrayList[String]): Boolean = {
        var tempWord : String = ""
        var tempString : String = ""
        var result = false
        for(x <- 0 until allWordsMF.size()){
          tempWord = allWordsMF.get(x)
          tempString = input
          while(tempWord.contains(".")){
            var removalIndex = allWordsMF.get(x).indexOf(".")
            tempWord = tempWord.substring(0,removalIndex)+tempWord.substring(removalIndex+1,tempWord.length())
            if(tempString.length()>removalIndex){
              tempString = tempString.substring(0,removalIndex)+tempString.substring(removalIndex+1,tempString.length())
            }
            if(tempWord.equals(tempString)){
              result = true
            }
          }
          if(tempWord.equals(tempString)){
            result = true
          }
        }
        result
      }
      
      println("Pattern input is: "+pattern)
      println("Removed mark: "+replaceQMark(pattern))
      val grammar = parseHead(replaceQMark(pattern)) 
      println(printTree(grammar))
      
      list = makeOptions(printTree(grammar))
        
      for(x <- 0 until list.size()){
        println("Option: "+list.get(x))
      }
      
      println("Enter 'q' at any time to quit.")
      var input = "L";
      while(!input.toUpperCase().equals("Q")){
        println("Please give an input.")
        input = scone.nextLine()
        index = 0
        var matches = false
        
        if(analyseDisBitch(input,list)){
          println("Got em.")
        }
        else {
          println(":(")
        }
      }
      println("Goodbye.")
    }
  }
