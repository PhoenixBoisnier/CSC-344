

object MacroParser4 {
  
  def main(args: Array[String]) {
    
    def replaceQMark(input: String): String = {
        var index = input.length() 
        var output = ""
        while(index>0){
          if(!input.substring(index-1, index).equals("?")){
            output = input.substring(index-1, index)+output
          }
          else {
            if(!input.substring(index-2, index-1).equals(")")){
              output = "("+input.substring(index-2, index-1)+"|_)"+output
              index = index-1
            }
            else {
              var subIndex = index-3
              var parCount = 1
              while(parCount>0){
                if(input.substring(subIndex, subIndex+1).equals(")")){
                  parCount = parCount+1
                }
                if(input.substring(subIndex, subIndex+1).equals("(")){
                  parCount = parCount-1
                }
                subIndex = subIndex-1
              }
              index = index-2
              output = input.substring(subIndex+2,index)+"|_)"+output
              index = subIndex+3
            }
          }
          index = index-1
        }
        if(output.contains("?")){
          output = replaceQMark(output)
        }
        output
      }
    
    abstract class Tree
    case class OrsPt(l: Tree, r: Tree) extends Tree
    case class AndPt(l: Tree, r: Tree) extends Tree
    case class InPar(t: Tree) extends Tree
    case class Leavz(v: String) extends Tree
    
    var results = new java.util.ArrayList[String]
    
    def produceResults(t: Tree): String = t match {
      case OrsPt(l,r)=>{
        println("Or left side: "+produceResults(l))
        println("Or right side: "+produceResults(r))
        ""
      }
      case AndPt(l,r)=>{
        println("And: "+produceResults(l)+produceResults(r))
        ""
      }
      case InPar(t)=>produceResults(t)
      case Leavz(v)=>{
        if(v.equals("_")){
          ""
        }
        else v
      }
    }
    
    val fakeNews = AndPt(Leavz("A"),OrsPt(Leavz("B"),Leavz("C")))
    produceResults(fakeNews)
  }
  
}