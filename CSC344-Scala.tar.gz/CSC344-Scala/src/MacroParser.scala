

  object MacroParser {
    def main(args: Array[String]) {
      val scone = new java.util.Scanner(System.in);
      println("Please input the grammar pattern.")
      val pattern = scone.nextLine();
      val letter = ".".r 
      
      var index = 0
      
      abstract class Tree
      case class Const(v: String) extends Tree
      case class SNode(e: Tree) extends Tree
      case class ENode(t: Tree, E2: Tree) extends Tree
      case class E2Node(Bar: String, E3: Tree) extends Tree
      case class E3Node(t: Tree, E2: Tree) extends Tree
      case class TNode(f: Tree, T2: Tree) extends Tree
      case class FNode(a: Tree, F2: Tree) extends Tree
      case class AANode(c: Tree) extends Tree
      case class ABNode(OpenPar: String, A2: Tree) extends Tree
      case class A2Node(e: Tree, ClosePar: String) extends Tree
      case class F2Node(QMark: String, F2: Tree) extends Tree
      case class T2Node(f: Tree, T2: Tree) extends Tree
      
      
      /*
      -S  -> E
      -E  -> T E2
      -E2 -> '|' E3
      -E2 -> NIL
      -E3 -> T E2
      -T  -> F T2
      -T2 -> F T2
      -T2 -> NIL
      -F  -> A F2
      -F2 -> '?' F2
      -F2 -> NIL
      -A  -> C
      -A  -> '(' A2
      -A2 -> E ')'
       */  
      
      def process(pattern: String): Tree = {
        SNode(parseENode(pattern))
      }
      
      def parseENode(pattern: String): Tree = {
        ENode(parseTNode(pattern), parseE2Node(pattern))
      }
      
      def parseTNode(pattern: String): Tree = {
        TNode(parseFNode(pattern), parseT2Node(pattern))
      }
      
      def parseFNode(pattern: String): Tree = {
        FNode(parseANode(pattern), parseF2Node(pattern))
      }
      
      def parseANode(pattern: String): Tree = {
        if((index+1)<=pattern.length()
            &&pattern.substring(index, index+1).equals("(")){
          index=index+1
          ABNode("(", parseA2Node(pattern))
        }
        else {
          AANode(parseConst(pattern))
        }
      }
      
      def parseConst(pattern: String): Tree = {
        index = index+1
        Const(pattern.substring(index-1, index))
      }
      
      def parseA2Node(pattern: String): Tree = {
        A2Node(parseENode(pattern), ")")
      }
      
      def parseE2Node(pattern: String): Tree = {
        if((index+1)<=pattern.length()
            &&pattern.substring(index, index+1).equals("|")){
          index = index+1;
          E2Node("|", parseE3Node(pattern))
        }
        else {
          Const("")
        }
      }
      
      def parseE3Node(pattern: String): Tree = {
        E3Node(parseTNode(pattern), parseE2Node(pattern))
      }
      
      def parseF2Node(pattern: String): Tree = {
        if((index+1)<=pattern.length()
            &&pattern.substring(index, index+1).equals("?")){
          index = index+1
          F2Node("?", parseF2Node(pattern))
        }
        else {
          Const("")
        }
      }
      
      def parseT2Node(pattern: String): Tree = {
        if(index<pattern.length()){
          T2Node(parseFNode(pattern), parseT2Node(pattern))
        }
        else {
          Const("")
        }
      }
      
      def printTree(t: Tree): String = t match {
        case SNode(e) => printTree(e)
        case ENode(t, e2) => printTree(t) + printTree(e2)
        case E2Node(bar, e3) => "|" + printTree(e3)
        case E3Node(t, e2) => printTree(t) + printTree(e2)
        case TNode(f, t2) => printTree(f) + printTree(t2)
        case FNode(a, f2) => printTree(a) + printTree(f2)
        case AANode(c) => printTree(c)
        case ABNode(openpar, a2) => openpar+printTree(a2)
        case A2Node(e, closepar) => printTree(e)
        case F2Node(qmark, f2) => "?" + printTree(f2)
        case T2Node(f, t2) => printTree(f) + printTree(t2)
        case Const(v) => v 
      }
      
      def replaceQMark(input: String): String = {
        var index = input.length() 
        var output = ""
        while(index>0){
          if(!input.substring(index-1, index).equals("?")){
            output = input.substring(index-1, index)+output
          }
          else {
            if(!input.substring(index-2, index-1).equals(")")){
              output = "("+input.substring(index-2, index-1)+"|_)"+output
              index = index-1
            }
            else {
              var subIndex = index-3
              var parCount = 1
              while(parCount>0){
                if(input.substring(subIndex, subIndex+1).equals(")")){
                  parCount = parCount+1
                }
                if(input.substring(subIndex, subIndex+1).equals("(")){
                  parCount = parCount-1
                }
                subIndex = subIndex-1
              }
              index = index-2
              output = input.substring(subIndex+2,index)+"|_)"+output
              index = subIndex+3
            }
          }
          index = index-1
        }
        if(output.contains("?")){
          output = replaceQMark(output)
        }
        output
      }
      
      def findString(input: String): Integer = {
        var index = input.length()-1
        var openPar = 1
        while((index>0) && (!input.substring(index-1, index).equals("|")) || 
            openPar > 0){
          if(input.substring(index-1, index).equals(")")){
            openPar = openPar+1
          }
          if(input.substring(index-1, index).equals("(")){
            openPar = openPar-1
          }
          index = index -1
        }
        index
      }
      
      def trimLastString(input: String): String = {
        input.substring(0,findString(input)-1)
      }
      
      def analyse(input: String, grammar: String): Boolean = {
        var matches = false
        var optionsList = allOptions(replaceQMark(grammar))
        
        for(x <- 0 until optionsList.size()){
          if(!optionsList.get(x).contains(".")){
            if(input.equals(optionsList.get(x))){
              matches = true
            }
          }
          else {
            var tempOption = optionsList.get(x)
            var tempInput = input
            while(tempOption.contains(".")){
              if(tempOption.indexOf(".")==0){
                if(!letter.findAllIn(tempInput.substring(tempOption.indexOf("."),
                    tempOption.indexOf("."))).equals(null)){
                  tempInput = tempInput.substring(tempOption.indexOf(".")+1)
                  tempOption = tempOption.substring(tempOption.indexOf(".")+1)
                }
              }
              else {
                if(tempInput.substring(0, tempOption.indexOf(".")).equals(
                    tempOption.substring(0, tempOption.indexOf(".")))){
                  tempInput = tempInput.substring(tempOption.indexOf("."))
                  tempOption = tempOption.substring(tempOption.indexOf("."))
                }
                else {
                  tempOption = ""
                }
              }
            }
            if(tempInput.equals(tempOption)){
              matches = true
            }
          }
          if(matches){
            return true
          }
        }
        matches
      }
      
      def listOptions(input: String): java.util.ArrayList[String] = {
        var list = new java.util.ArrayList[String]
        var editInput = trimPars(input)
        
        while(!editInput.equals("")&&editInput.contains("|")){
          list.add(editInput.substring(0,editInput.indexOf("|")))
          editInput = editInput.substring(editInput.indexOf("|")+1)
        }
        if((!editInput.equals("")) && (!editInput.equals("_"))){
          list.add(editInput)
        }
        list
      }
      
      def allOptions(input: String): java.util.ArrayList[String] = {
        var list = new java.util.ArrayList[String]
        //base case: only a single option remains
        var firstHalf : String = ""
        var secndHalf : java.util.ArrayList[String] = 
          new java.util.ArrayList[String]
        var thirdHalf : java.util.ArrayList[String] = 
          new java.util.ArrayList[String]
        //in the case that there is a nested option left
        if(input.contains("(")){
          if(!input.substring(0,1).equals("(")){
            firstHalf = input.substring(0, 
              input.indexOf("("))
          }
          var openPar = 1;
          var lastPar = input.indexOf("(")+1
          while((openPar>0)&&(lastPar<input.length())){
            if(input.substring(lastPar,lastPar+1).equals("(")){
              openPar = openPar + 1
            }
            if(input.substring(lastPar,lastPar+1).equals(")")){
              openPar = openPar - 1
            }
            lastPar = lastPar + 1
          }
          if(lastPar<input.length()){
            thirdHalf = allOptions(input.substring(lastPar))
          }
          secndHalf = allOptions(trimPars(
              input.substring(input.indexOf("("), lastPar)))
        }
        //in the case that there are options (a|b)
        else if(input.contains("|")){
          var aftIndex = 0
          var begIndex = aftIndex
          while(aftIndex<input.length()){
            if(input.substring(aftIndex, aftIndex+1).equals("|")){
              var adding = allOptions(input.substring(begIndex, aftIndex))
              aftIndex = aftIndex + 1
              begIndex = aftIndex
              for(x <- 0 until adding.size()){
                list.add(adding.get(x))
              }
            }
            else {
              aftIndex = aftIndex + 1
            }
          }
          var adding = allOptions(input.substring(begIndex, aftIndex))
          for(x <- 0 until adding.size()){
            list.add(adding.get(x))
          }
        }
        //in the case that there is no secndHalf or thirdHalf
        else {
          if(input.equals("_")){
            list.add("")
          }
          else list.add(input)
        }
        if(secndHalf.size()==0){
          secndHalf.add("")
        }
        if(thirdHalf.size()==0){
          thirdHalf.add("")
        }
        if(firstHalf.equals("_")){
          firstHalf = ""
        }
        for(x <- 0 until secndHalf.size()){
          for(y <- 0 until thirdHalf.size()){
            list.add(firstHalf+secndHalf.get(x)+thirdHalf.get(y))
          }
        }
        list
      }
      
      def trimPars(input: String): String = {
        var output = input
        if(output.substring(input.length()-1, input.length()).equals(")")
            &&output.substring(0,1).equals("(")){
          output = output.substring(0, output.length()-1)
          output = output.substring(1)
        }
        output
      }
      
      
        
      
      def matchIt(input: String, grammar: Tree): Boolean = grammar match {
        
        case SNode(e) => matchIt(input, e)
        
        
        if(input.contains("|")||input.contains("?")||input.contains("(")
            ||input.contains(")")||input.contains(".")){
          return false
        }
   /*   else if(!(grammar.contains("|")||grammar.contains("?")||
            grammar.contains("(")||grammar.contains(")")||
            grammar.contains("."))){
          if(input.equals(grammar)){
            return true
          }
          else return false
        }
        else {
          /*
           * go letter by letter to see if there is a match until we encounter
           * 		a ) or | or ? then skip to next char after ), set iIndexKick
           * if we encounter a non-match, look for a | and start over from
           * 		index prior to last kick
           * else kick out of the current () to look for either a | or ?
           * if it is a ?, continue on, match is still valid
           * if it is a |, move to next set after |
           * else no match
           */
        }
        while(iIndex<input.length() && gIndex<grammar.length()){
          //easy case, they match, huzzah!
          if(input.substring(iIndex, iIndex+1).equals(
              grammar.substring(gIndex, gIndex+1))){
            iIndex = iIndex+1
            gIndex = gIndex+1
          }
          //less easy case, grammar got a . 
          else if(grammar.substring(gIndex, gIndex+1).equals(".")){
            if(!letter.findAllIn(input.substring(iIndex, iIndex+1)).equals(null)){
              iIndex = iIndex+1
              gIndex = gIndex+1
            }
            else {
              iIndex = input.length()
              matches = false
            }
          }
          else if(((gIndex+2)<grammar.length())&&grammar.substring(
              gIndex+1, gIndex+2).equals("?")){
            
          }
          else {
            iIndex = input.length()
            matches = false
          }
        }*/
        true
      }
      
      
      
      val grammar = process(pattern)
      println("Enter 'q' at any time to quit.")
      var input = "L";
      while(!input.toUpperCase().equals("Q")){
        println("Please give an input.")
        input = scone.nextLine()
        index = 0
        input = replaceQMark(input)
        println(replaceQMark(printTree(grammar)))
        if(analyse(input, printTree(grammar))){
          println("Matches.")
        }
        else println("Does not match.")
      }
      println("Goodbye.")
    }
  }
