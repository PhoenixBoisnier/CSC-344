/*
 ============================================================================
 Name        : CSC344-TextFinisher.c
 Author      : Phoenix Boisnier
 Version     :
 Copyright   : C is dumb.
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

//A node for the stupidCTrie, that would not be stupid if this weren't C.
struct stupidCTrieNode{

	char val;
	char word[100];
	struct stupidCTrieNode *nexts[256];

};

//A trie that is stupid because it is written in C.
struct stupidCTrie{

	struct stupidCTrieNode *head[256];

};

//Adds a string to the trie at the end of its path.
void addToStupidCTrie(struct stupidCTrieNode *node, char string[], int index){
	char c = string[index];
	node->val = c;
	if(string[index]=='\0'){
		for(int i = 0; i<100; i++){
			node->word[i] = string[i];
			if(string[i]=='\0'){
				break;
			}
		}
	}
	else {
		int next = c;
		if(node->nexts[next]==NULL){
			node->nexts[next] = (struct stupidCTrieNode*)malloc(
					sizeof(struct stupidCTrieNode));
		}
		addToStupidCTrie(node->nexts[next], string, ++index);
	}
}

//Prints the results in the trie from specified node.
void printStupidCResults(struct stupidCTrieNode *node){
	if(node->word[0]!='\0'){
		printf("%s\n",node->word);
	}
	if((node->word[0]=='\0')&&(node->val=='\0')){
	}
	else if((node->word[0]!='\0')&&(node->val=='\0')){
		printf("%s\n",node->word);
	}
	else {
		for(int i = 0; i<256; i++){
			if(node->nexts[i]!=NULL){
				printStupidCResults(node->nexts[i]);
			}
		}
	}
}

void getToStupidNode(struct stupidCTrieNode *node, char string[], int index){
	if(node==NULL){
		printf("No results matching prefix.\n");
	}
	else if(string[index]=='\0'){
		if(node->word[0]!='\0'){
			printf("%s\n",node->word);
		}
		printStupidCResults(node);
	}
	else {
		int next = string[index];
		if(node->nexts[next]!=NULL){
			getToStupidNode(node->nexts[next], string, index+1);
		}
		else {
			printf("No results matching prefix.\n");
		}
	}
}

// This method trims strings, like in Java, because Java is superior.
void trimString(char string[]){
	int length = 0;
	while(string[length]!='\0'){
		length++;
	}
	length++;
	char trimmed[length];
	for(int i = 0; i<length; i++){
		trimmed[i] = string[i];
	}
	//Have I mentioned that C is dumb?
	string = (char*)malloc(sizeof(char[length-1]));
	string = trimmed;
}

int main(void) {

	int running = 1;

	//main loop that runs the program
	while(running>0){

		//Variables located here
		char path[100];
		char* ppath = (char*)malloc(sizeof(char[100]));
		char fileName[100];
		char* pfileName = (char*)malloc(sizeof(char[100]));
		struct stupidCTrie trie;
		for(int i = 0; i<256; i++){
			trie.head[i] = NULL;
		}

		printf("Please input path (0 to exit):\n");
		scanf("%s",path);
		if(path[0]=='0'){
			printf("Exit command confirmed.\n");
			running*=-1;
			break;
		}
		//After all the decisions are made, ppath is assigned to path
		ppath = path;
		trimString(ppath);

		//We now determine which file prefix will be searched for
		//Also, C is a bad language.
		printf("Type the first few letters of file (0 to exit):\n");
		printf(">");
		scanf("%s",fileName);
		if(fileName[0]=='0'){
			printf("Exit command confirmed.\n");
			running*=-1;
			break;
		}
		pfileName = fileName;
		trimString(pfileName);
		//Now we search through all files in the path to find matches to
		//the specified prefix.
		DIR *dp;
		struct dirent *ep;
		dp = opendir (ppath);
		if (dp != NULL) {
			while ((ep = readdir (dp))){
				char addingWord[256];
				char* paddingWord = (char*)malloc(sizeof(char[100]));
				paddingWord = ep->d_name;
				trimString(addingWord);
				char branchNo = paddingWord[0];
				if(trie.head[branchNo]==NULL){
					trie.head[branchNo] = (struct stupidCTrieNode*)malloc(
							sizeof(struct stupidCTrieNode));
					addToStupidCTrie(trie.head[branchNo],paddingWord,0);
				}
				else {
					addToStupidCTrie(trie.head[branchNo],paddingWord,0);
				}
			}
			(void) closedir (dp);
		}
		else perror ("Couldn't open the directory");
		getToStupidNode(trie.head[(fileName[0])],fileName,0);
		for(int i = 0; i<256; i++){
			trie.head[i] = NULL;
		}
		ppath = "\0";
		pfileName = "\0";
		for(int i = 0; i<256; i++){
			trie.head[i] = NULL;
			trie.head[i] = (struct stupidCTrieNode*)malloc(
					sizeof(struct stupidCTrieNode));
		}
	}

	printf("Goodbye.\n");
	return EXIT_SUCCESS;
}
